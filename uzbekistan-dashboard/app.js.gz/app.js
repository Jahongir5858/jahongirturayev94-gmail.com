(() => {
  'use strict';

  const C = window.DASH_CONFIG || {};
  const R = window.DASH_RAW;
  if (!R) throw new Error('Dashboard ma’lumotlari topilmadi');

  const D = {
    meta:{centers2026:R.m[0],proposals2027:R.m[1],districts208:R.m[2],selected2027Districts:R.m[3],selected2026Districts:R.m[4],population:R.m[5]},
    centers2026:R.c.map(x=>({id:x[0],region:x[1],district:x[2],centerName:x[3],objectName:x[4],lat:+x[5],lng:+x[6],objectType:x[7],inSon:!!x[8],year:2026})),
    proposals2027:R.p.map(x=>({id:x[0],region:x[1],district:x[2],mfy:x[3],objectName:x[4],lat:+x[5],lng:+x[6],objectType:x[7],floor:x[8],balanceType:x[9],balance:x[10],landArea:x[11],area:x[12],selectedOfficial:!!x[13],year:2027})),
    districts208:R.d.map(x=>({id:x[0],region:x[1],district:x[2],population:+x[3]||0,registry:+x[4]||0,disabilities:+x[5]||0,orphans:+x[6]||0,elderly:+x[7]||0,status:x[8],totalShare:+x[9]||0}))
  };

  const COLORS={green:'#16a34a',red:'#dc2626',blue:'#2563eb',purple:'#9333ea'};
  const UZ={north:45.9,south:37.0,west:55.7,east:73.4};
  const ADM1_URL='https://raw.githubusercontent.com/Rakhmatovdev/uz-map/main/public/data/uzbekistan-adm1.geojson';
  const ADM2_URL='https://raw.githubusercontent.com/Rakhmatovdev/uz-map/main/public/data/uzbekistan-adm2.geojson';
  const MEDIA_ORIGIN=C.mediaApiOrigin||'https://mfc-telegram-worker.jahongirturayev94.workers.dev';

  const $=s=>document.querySelector(s);
  const $$=s=>[...document.querySelectorAll(s)];
  const esc=(v='')=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const fmt=n=>new Intl.NumberFormat('uz-UZ').format(Number(n)||0);
  const fmt1=n=>new Intl.NumberFormat('uz-UZ',{maximumFractionDigits:1}).format(Number(n)||0);
  const debounce=(fn,ms=120)=>{let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms)}};
  const norm=(s='')=>String(s).toLowerCase().normalize('NFKD')
    .replace(/[ʻʼ’`´]/g,"'").replace(/ў/g,"o'").replace(/ғ/g,"g'").replace(/қ/g,'q').replace(/ҳ/g,'h')
    .replace(/ч/g,'ch').replace(/ш/g,'sh').replace(/ж/g,'j').replace(/я/g,'ya').replace(/ю/g,'yu').replace(/ё/g,'yo')
    .replace(/ц/g,'s').replace(/[а-я]/g,c=>({а:'a',б:'b',в:'v',г:'g',д:'d',е:'e',з:'z',и:'i',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'x',ъ:'',ь:'',ы:'i',э:'e'}[c]||c))
    .replace(/\b(viloyati|viloyat|tumani|tuman|shahri|shahar|respublikasi|r)\b/g,' ')
    .replace(/[^a-z0-9'\s.-]/g,' ').replace(/\s+/g,' ').trim();

  const objects=[
    ...D.centers2026.map(x=>({...x,uid:`c26-${x.id}`,displayName:x.centerName,kind:'center'})),
    ...D.proposals2027.map(x=>({...x,uid:`p27-${x.id}`,displayName:x.objectName,kind:'proposal'}))
  ];
  objects.forEach(o=>o.searchKey=norm([o.region,o.district,o.mfy,o.displayName,o.objectName,o.centerName,o.balance,o.objectType].filter(Boolean).join(' ')));
  const byUid=new Map(objects.map(o=>[o.uid,o]));

  const state={year:'all',region:'',type:'',selectedOnly:false,q:'',selectedUid:null,renderLimit:30,mapType:'roadmap',traffic:false,boundaries:false,tilt:false};
  let map=null,mapsReady=false,clusterer=null,trafficLayer=null,placesService=null,geocoder=null,directionsService=null,directionsRenderer=null,streetService=null,streetPanorama=null,autocomplete=null;
  let markerMap=new Map(),searchMarker=null,adm1Layer=null,adm2Layer=null,adm2Loaded=false,mediaIndexPromise=null,toastTimer=null;
  const addressCache=new Map();

  function markerClass(o){if(o.year===2026&&o.inSon)return'purple';if(o.year===2026)return'green';if(o.selectedOfficial)return'blue';return'red'}
  function markerColor(o){return COLORS[markerClass(o)]||COLORS.red}
  function filteredObjects(){
    const q=norm(state.q);
    return objects.filter(o=>{
      if(state.year!=='all'&&String(o.year)!==state.year)return false;
      if(state.region&&o.region!==state.region)return false;
      if(state.type&&o.objectType!==state.type)return false;
      if(state.selectedOnly&&!(o.year===2027&&o.selectedOfficial))return false;
      if(q&&!o.searchKey.includes(q))return false;
      return true;
    });
  }

  function setKpis(){
    $('#kpiTotal').textContent=fmt(objects.length);$('#kpi2026').textContent=fmt(D.meta.centers2026);$('#kpi2027').textContent=fmt(D.meta.proposals2027);
    $('#kpiSelected').textContent=fmt(D.meta.selected2027Districts);$('#kpiDistricts').textContent=fmt(D.meta.districts208);$('#kpiPopulation').textContent=`${fmt1(D.meta.population/1e6)} mln`;
  }
  function populateRegions(){
    const regs=[...new Set([...objects.map(o=>o.region),...D.districts208.map(d=>d.region)].filter(Boolean))].sort((a,b)=>a.localeCompare(b,'uz'));
    $('#regionSelect').innerHTML='<option value="">Barcha hududlar</option>'+regs.map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join('');
  }

  function cardHtml(o){const mc=markerClass(o);return `<button class="object-card${o.uid===state.selectedUid?' active':''}" data-uid="${o.uid}" type="button" role="listitem"><span class="marker-badge ${mc}">${o.year===2026?'26':o.selectedOfficial?'✓':'27'}</span><span class="object-copy"><b>${esc(o.displayName||'Nomsiz obyekt')}</b><small>${esc(o.region)} · ${esc(o.district)}${o.objectType?' · '+esc(o.objectType):''}</small></span><span class="object-arrow">›</span></button>`}
  function renderList(reset=true){
    const rows=filteredObjects(),el=$('#objectList');
    $('#listSummary').textContent=`${fmt(rows.length)} ta obyekt`;$('#regionSummary').textContent=`${new Set(rows.map(r=>r.region)).size} hudud`;
    if(reset){state.renderLimit=30;el.innerHTML=''}
    if(!rows.length){el.innerHTML='<div class="empty-note">Filtr bo‘yicha obyekt topilmadi.</div>';return}
    const existing=el.querySelectorAll('.object-card').length;
    const end=Math.min(state.renderLimit,rows.length);
    if(reset)el.innerHTML=rows.slice(0,end).map(cardHtml).join('');
    else el.insertAdjacentHTML('beforeend',rows.slice(existing,end).map(cardHtml).join(''));
    el.querySelector('.load-more')?.remove();
    if(end<rows.length)el.insertAdjacentHTML('beforeend',`<button class="load-more" type="button" data-more="1">Yana ${Math.min(30,rows.length-end)} ta ko‘rsatish</button>`);
  }
  function loadMore(){const rows=filteredObjects();if(state.renderLimit>=rows.length)return;state.renderLimit+=30;renderList(false)}
  function syncActiveCard(){ $$('.object-card').forEach(x=>x.classList.toggle('active',x.dataset.uid===state.selectedUid)) }

  function syncFilters(){
    $$('.year-tab').forEach(b=>b.classList.toggle('active',b.dataset.year===state.year));
    $$('.kpi[data-year]').forEach(b=>b.classList.toggle('active',b.dataset.year===state.year));
    $('#regionSelect').value=state.region;$('#typeSelect').value=state.type;$('#selectedOnly').checked=state.selectedOnly;
  }
  function applyFilters({fit=false}={}){syncFilters();renderList(true);updateMarkers();if(fit)fitRows(filteredObjects())}
  function clearFilters(){state.year='all';state.region='';state.type='';state.selectedOnly=false;state.q='';$('#objectSearch').value='';applyFilters({fit:true})}

  function showToast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),3000)}
  function mapsStatus(mode,text){const s=$('#mapsStatus');s.className='maps-status'+(mode?' '+mode:'');s.lastChild.textContent=' '+text}
  function mapFailure(message){mapsReady=false;document.body.dataset.mapReady='error';mapsStatus('error','Xarita xatosi');$('#map').innerHTML=`<div class="map-error"><div><b>Google Maps yuklanmadi</b><p>${esc(message)}</p><p>Google Cloud’da Maps JavaScript API, Places API, Geocoding API va Routes API yoqilgan bo‘lishi, billing faol va joriy domen HTTP referrer sifatida ruxsat etilgan bo‘lishi kerak.</p></div></div>`}
  window.gm_authFailure=()=>mapFailure('Google Maps API kaliti joriy domen uchun avtorizatsiyadan o‘tmadi. HTTP referrer yoki API cheklovlarini tekshiring.');

  async function loadGoogleMaps(){
    if(!C.googleMapsApiKey)return mapFailure('Google Maps API kaliti konfiguratsiyada topilmadi.');
    if(window.google?.maps)return initGoogleMaps();
    const s=document.createElement('script');s.id='googleMapsApiScript';s.async=true;s.defer=true;
    window.__dashboardGoogleReady=()=>initGoogleMaps().catch(e=>{console.error(e);mapFailure('Google Maps komponentlarini ishga tushirib bo‘lmadi.')});
    s.src=`https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(C.googleMapsApiKey)}&libraries=places,geometry,marker&language=uz&region=UZ&v=weekly&loading=async&auth_referrer_policy=origin&callback=__dashboardGoogleReady`;
    s.onerror=()=>mapFailure('Google Maps JavaScript kutubxonasini yuklab bo‘lmadi. Internet yoki API sozlamalarini tekshiring.');document.head.appendChild(s);
  }

  async function initGoogleMaps(){
    const mapsLib=await google.maps.importLibrary('maps');
    const geocodeLib=await google.maps.importLibrary('geocoding');
    const routesLib=await google.maps.importLibrary('routes');
    const placesLib=await google.maps.importLibrary('places');
    const center=C.defaultCenter||{lat:41.3775,lng:64.5853};
    map=new mapsLib.Map($('#map'),{center,zoom:C.defaultZoom||6,mapTypeId:'roadmap',disableDefaultUI:true,zoomControl:true,streetViewControl:true,fullscreenControl:false,gestureHandling:'greedy',restriction:{latLngBounds:UZ,strictBounds:false},clickableIcons:true});
    geocoder=new geocodeLib.Geocoder();directionsService=new routesLib.DirectionsService();directionsRenderer=new routesLib.DirectionsRenderer({map,preserveViewport:false,suppressInfoWindows:true});
    placesService=new google.maps.places.PlacesService(map);streetService=new google.maps.StreetViewService();trafficLayer=new google.maps.TrafficLayer();
    initAutocomplete(placesLib);buildMarkers();
    map.addListener('idle',()=>{if(!mapsReady){mapsReady=true;document.body.dataset.mapReady='true';mapsStatus('ready','Google Maps ulandi')}});
    map.addListener('zoom_changed',()=>{if(state.boundaries&&map.getZoom()>=7&&!adm2Loaded)loadAdm2()});
    fitRows(objects,false);
  }

  function initAutocomplete(){
    const input=$('#placeSearch');
    autocomplete=new google.maps.places.Autocomplete(input,{componentRestrictions:{country:'uz'},fields:['formatted_address','geometry','name','place_id']});
    autocomplete.addListener('place_changed',()=>{const p=autocomplete.getPlace();if(!p.geometry?.location)return;const pos={lat:p.geometry.location.lat(),lng:p.geometry.location.lng()};map.panTo(pos);map.setZoom(15);if(searchMarker)searchMarker.setMap(null);searchMarker=new google.maps.Marker({map,position:pos,title:p.name||p.formatted_address,animation:google.maps.Animation.DROP});showToast(p.name||p.formatted_address||'Joy topildi')});
  }

  function buildMarkers(){
    markerMap.forEach(m=>m.setMap(null));markerMap.clear();
    for(const o of objects){if(!Number.isFinite(o.lat)||!Number.isFinite(o.lng))continue;const m=new google.maps.Marker({position:{lat:o.lat,lng:o.lng},title:o.displayName,map:null,optimized:true,icon:{path:google.maps.SymbolPath.CIRCLE,scale:o.selectedOfficial?8:7,fillColor:markerColor(o),fillOpacity:.96,strokeColor:'#ffffff',strokeOpacity:1,strokeWeight:2}});m.__uid=o.uid;m.addListener('click',()=>selectObject(o.uid,true));markerMap.set(o.uid,m)}
    updateMarkers();
  }
  function updateMarkers(){
    if(!map)return;const visible=filteredObjects().map(o=>markerMap.get(o.uid)).filter(Boolean);
    if(clusterer){clusterer.clearMarkers();clusterer.setMap(null);clusterer=null}
    markerMap.forEach(m=>m.setMap(null));
    if(window.markerClusterer?.MarkerClusterer){clusterer=new markerClusterer.MarkerClusterer({map,markers:visible,algorithmOptions:{maxZoom:12}})}else visible.forEach(m=>m.setMap(map));
  }
  function fitRows(rows=filteredObjects(),animate=true){
    if(!map||!rows.length)return;const valid=rows.filter(o=>Number.isFinite(o.lat)&&Number.isFinite(o.lng));if(!valid.length)return;
    if(valid.length===1){map.panTo({lat:valid[0].lat,lng:valid[0].lng});map.setZoom(11);return}
    const b=new google.maps.LatLngBounds();valid.forEach(o=>b.extend({lat:o.lat,lng:o.lng}));map.fitBounds(b,innerWidth<820?55:{top:170,right:90,bottom:70,left:370});
    if(!animate)google.maps.event.addListenerOnce(map,'idle',()=>{if(map.getZoom()>9)map.setZoom(9)});
  }
  function fitUzbekistan(){if(!map)return;const b=new google.maps.LatLngBounds({lat:UZ.south,lng:UZ.west},{lat:UZ.north,lng:UZ.east});map.fitBounds(b,innerWidth<820?50:{top:165,right:85,bottom:65,left:365})}

  async function selectObject(uid,fly=true){
    const o=byUid.get(uid);if(!o)return;state.selectedUid=uid;syncActiveCard();renderDetail(o);$('#detailDrawer').classList.add('open');$('#explorer').classList.remove('mobile-open');
    if(map&&fly){map.panTo({lat:o.lat,lng:o.lng});if(map.getZoom()<11)map.setZoom(11)}
    resolveAddress(o);loadPhotos(o);
  }
  function closeDetail(){state.selectedUid=null;$('#detailDrawer').classList.remove('open');syncActiveCard()}

  function detailRows(o){return o.year===2026?[
    ['Yil','2026'],['Obyekt turi',o.objectType||'—'],['Hudud',o.region],['Tuman / shahar',o.district],['Kenglik',o.lat.toFixed(6)],['Uzunlik',o.lng.toFixed(6)]
  ]:[['Yil','2027'],['Obyekt turi',o.objectType||'—'],['MFY',o.mfy||'—'],['Qavat',o.floor||'—'],['Yer maydoni',o.landArea?`${fmt1(o.landArea)} ga`:'—'],['Bino maydoni',o.area?`${fmt1(o.area)} m²`:'—'],['Balans turi',o.balanceType||'—'],['Balans',o.balance||'—']];}
  function renderDetail(o){
    const mc=markerClass(o),selected=o.year===2027&&o.selectedOfficial;
    $('#detailContent').innerHTML=`<div class="detail-wrap"><div class="detail-head"><div class="detail-title"><div class="badge-row"><span class="badge ${mc}">${o.year} · ${mc==='green'?'MARKAZ':mc==='purple'?'INSON':mc==='blue'?'TANLANGAN':'TAKLIF'}</span>${selected?'<span class="badge">Rasmiy tanlov</span>':''}</div><h2>${esc(o.displayName)}</h2></div><button id="detailClose" class="close-btn" type="button">×</button></div><div class="detail-loc">${esc(o.region)} · ${esc(o.district)}${o.mfy?' · '+esc(o.mfy):''}</div><div id="addressLine" class="address-line">Google Geocoding orqali manzil aniqlanmoqda…</div><div class="detail-grid">${detailRows(o).map(([k,v])=>`<div class="detail-cell"><small>${esc(k)}</small><b>${esc(v)}</b></div>`).join('')}</div><div class="detail-actions"><button id="focusObject" class="primary" type="button">Xaritada ko‘rsatish</button><button id="routeObject" type="button">Yo‘nalish</button><button id="streetObject" type="button">Street View</button><button id="nearbyObject" type="button">Yaqin xizmatlar</button></div><div class="detail-section"><h3>TELEGRAM MEDIA</h3><div id="photoGrid" class="photo-grid"><div class="empty-note">Rasmlar tekshirilmoqda…</div></div></div><div class="detail-section"><h3>GOOGLE PLACES · YAQIN OBYEKTLAR</h3><div id="nearbyList" class="nearby-list"><div class="empty-note">“Yaqin xizmatlar” tugmasini bosing.</div></div></div></div>`;
    $('#detailClose').onclick=closeDetail;$('#focusObject').onclick=()=>selectObject(o.uid,true);$('#routeObject').onclick=()=>routeTo(o);$('#streetObject').onclick=()=>openStreetView(o);$('#nearbyObject').onclick=()=>loadNearby(o);
  }

  async function resolveAddress(o){
    const el=$('#addressLine');if(!el||state.selectedUid!==o.uid)return;if(addressCache.has(o.uid)){el.textContent=addressCache.get(o.uid);return}
    if(!geocoder){el.textContent='Koordinata: '+o.lat.toFixed(6)+', '+o.lng.toFixed(6);return}
    try{const res=await geocoder.geocode({location:{lat:o.lat,lng:o.lng}});const address=res.results?.[0]?.formatted_address||'Manzil topilmadi';addressCache.set(o.uid,address);if(state.selectedUid===o.uid&&$('#addressLine'))$('#addressLine').textContent=address}catch{if(state.selectedUid===o.uid&&$('#addressLine'))$('#addressLine').textContent='Koordinata: '+o.lat.toFixed(6)+', '+o.lng.toFixed(6)}
  }

  async function ensureMediaIndex(){
    if(mediaIndexPromise)return mediaIndexPromise;
    mediaIndexPromise=fetch(`${MEDIA_ORIGIN}/media/list`,{cache:'no-store'}).then(r=>r.ok?r.json():null).then(x=>x?.configured?x.centers||{}:{}).catch(()=>({}));return mediaIndexPromise;
  }
  async function loadPhotos(o){
    const grid=$('#photoGrid');if(!grid||state.selectedUid!==o.uid)return;const idx=await ensureMediaIndex();if(state.selectedUid!==o.uid||!$('#photoGrid'))return;
    const key=`${o.year}/${String(Number(o.id)||o.id).padStart(3,'0')}`,count=Number(idx[key]||0);
    if(!count){$('#photoGrid').innerHTML='<div class="empty-note">Telegram media bazasida ushbu obyekt uchun rasm topilmadi.</div>';return}
    $('#photoGrid').innerHTML=Array.from({length:Math.min(count,6)},(_,i)=>`<a class="photo-card" href="${MEDIA_ORIGIN}/media/${key}/${String(i+1).padStart(2,'0')}" target="_blank" rel="noopener"><img loading="lazy" decoding="async" src="${MEDIA_ORIGIN}/media/${key}/${String(i+1).padStart(2,'0')}" alt="${esc(o.displayName)} — ${i+1}-rasm"><span>${i+1} / ${count}</span></a>`).join('');
  }

  async function currentLocation(){return new Promise((resolve,reject)=>{if(!navigator.geolocation)return reject(new Error('Geolokatsiya mavjud emas'));navigator.geolocation.getCurrentPosition(p=>resolve({lat:p.coords.latitude,lng:p.coords.longitude}),reject,{enableHighAccuracy:true,timeout:10000,maximumAge:30000})})}
  async function locate(){try{const pos=await currentLocation();map?.panTo(pos);map?.setZoom(14);showToast('Joriy joylashuv topildi')}catch{showToast('Joylashuv ruxsati berilmadi')}}
  async function routeTo(o){
    if(!directionsService||!directionsRenderer)return showToast('Routes API hali tayyor emas');$('#routeBar').hidden=false;$('#routeSummary').textContent='Joriy joylashuv olinmoqda…';
    try{const origin=await currentLocation();const res=await directionsService.route({origin,destination:{lat:o.lat,lng:o.lng},travelMode:google.maps.TravelMode.DRIVING,provideRouteAlternatives:false});directionsRenderer.setDirections(res);const leg=res.routes?.[0]?.legs?.[0];$('#routeSummary').textContent=leg?`${leg.distance?.text||''} · ${leg.duration?.text||''} · ${esc(o.district)}`:'Yo‘nalish tayyor';$('#detailDrawer').classList.remove('open')}catch(e){console.warn(e);$('#routeBar').hidden=true;showToast('Yo‘nalish hisoblanmadi. Routes API yoki geolokatsiyani tekshiring')}
  }
  function clearRoute(){directionsRenderer?.setDirections({routes:[]});$('#routeBar').hidden=true}

  async function openStreetView(o){
    if(!streetService)return showToast('Street View hali tayyor emas');$('#streetViewSheet').hidden=false;$('#streetTitle').textContent=`${o.district} · ${o.displayName}`;$('#streetView').innerHTML='<div class="map-loading"><span class="loader-ring"></span><b>Street View qidirilmoqda</b></div>';
    try{const data=await streetService.getPanorama({location:{lat:o.lat,lng:o.lng},radius:200,source:google.maps.StreetViewSource.OUTDOOR});$('#streetView').innerHTML='';streetPanorama=new google.maps.StreetViewPanorama($('#streetView'),{position:data.data?.location?.latLng||data.location?.latLng,pov:{heading:0,pitch:0},zoom:1,addressControl:true,fullscreenControl:false})}catch{$('#streetView').innerHTML='<div class="empty-note" style="margin:20px">Bu nuqta yaqinida Street View topilmadi.</div>'}
  }
  function closeStreet(){$('#streetViewSheet').hidden=true;streetPanorama=null}

  async function loadNearby(o){
    const el=$('#nearbyList');if(!el)return;if(!placesService){el.innerHTML='<div class="empty-note">Places API hali tayyor emas.</div>';return}el.innerHTML='<div class="empty-note">Google Places qidiruvi bajarilmoqda…</div>';
    try{const result=await new Promise((resolve,reject)=>placesService.nearbySearch({location:{lat:o.lat,lng:o.lng},radius:4000,keyword:'shifoxona dorixona maktab davlat xizmatlari'},(rows,status)=>status===google.maps.places.PlacesServiceStatus.OK?resolve(rows):reject(status)));const rows=result.slice(0,8);el.innerHTML=rows.length?rows.map(p=>{const loc=p.geometry?.location;const d=loc?haversine({lat:o.lat,lng:o.lng},{lat:loc.lat(),lng:loc.lng()}):null;return `<div class="nearby-item"><span><b>${esc(p.name||'Obyekt')}</b><small>${esc(p.vicinity||'')}</small></span><em>${d!=null?`${d.toFixed(1)} km`:p.rating?`★ ${p.rating}`:''}</em></div>`}).join(''):'<div class="empty-note">4 km ichida mos obyekt topilmadi.</div>'}catch{el.innerHTML='<div class="empty-note">Places qidiruvi bajarilmadi. Places API ruxsatlarini tekshiring.</div>'}
  }
  function haversine(a,b){const R=6371,dLat=(b.lat-a.lat)*Math.PI/180,dLon=(b.lng-a.lng)*Math.PI/180,x=Math.sin(dLat/2)**2+Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLon/2)**2;return 2*R*Math.asin(Math.sqrt(x))}

  function toggleTraffic(){if(!map)return;state.traffic=!state.traffic;trafficLayer.setMap(state.traffic?map:null);$('#trafficBtn').classList.toggle('active',state.traffic);showToast(state.traffic?'Jonli tirbandlik qatlami yoqildi':'Tirbandlik qatlami o‘chirildi')}
  function toggleMapTypeMenu(){const m=$('#mapTypeMenu');m.hidden=!m.hidden}
  function setMapType(type){state.mapType=type;map?.setMapTypeId(type);$$('#mapTypeMenu [data-maptype]').forEach(b=>b.classList.toggle('active',b.dataset.maptype===type));$('#mapTypeMenu').hidden=true}
  function toggleTilt(){if(!map)return;state.tilt=!state.tilt;if(state.tilt){if(!['satellite','hybrid'].includes(state.mapType))setMapType('hybrid');map.setZoom(Math.max(map.getZoom(),16));map.setTilt(45)}else map.setTilt(0);$('#tiltBtn').classList.toggle('active',state.tilt)}

  function toggleBoundaries(){state.boundaries=!state.boundaries;$('#boundaryBtn').classList.toggle('active',state.boundaries);if(!map)return;if(!state.boundaries){adm1Layer?.setMap(null);adm2Layer?.setMap(null);return}loadAdm1();if(map.getZoom()>=7)loadAdm2()}
  function loadAdm1(){if(adm1Layer){adm1Layer.setMap(map);return}adm1Layer=new google.maps.Data({map});adm1Layer.setStyle({fillColor:'#0e94a0',fillOpacity:.025,strokeColor:'#167f91',strokeOpacity:.6,strokeWeight:1.2});adm1Layer.loadGeoJson(ADM1_URL,null,features=>{if(!features?.length)showToast('Viloyat chegaralari yuklanmadi')})}
  function loadAdm2(){if(adm2Loaded){adm2Layer?.setMap(map);return}adm2Loaded=true;adm2Layer=new google.maps.Data({map});adm2Layer.setStyle({fillOpacity:0,strokeColor:'#5f8794',strokeOpacity:.35,strokeWeight:.6});adm2Layer.loadGeoJson(ADM2_URL,null,features=>{if(!features?.length)showToast('Tuman chegaralari yuklanmadi')})}

  function renderAnalysis(){
    const total=(k)=>D.districts208.reduce((s,d)=>s+(+d[k]||0),0);const byRegion=new Map();
    for(const d of D.districts208){const x=byRegion.get(d.region)||{region:d.region,pop:0,registry:0,dis:0,districts:0,objects:0};x.pop+=d.population;x.registry+=d.registry;x.dis+=d.disabilities;x.districts++;byRegion.set(d.region,x)}
    for(const o of objects){const x=byRegion.get(o.region);if(x)x.objects++}
    const regs=[...byRegion.values()].sort((a,b)=>b.pop-a.pop);const rank=[...D.districts208].sort((a,b)=>b.totalShare-a.totalShare).slice(0,20),max=Math.max(...rank.map(x=>x.totalShare),1);
    $('#analysisContent').innerHTML=`<div class="analysis-kpis"><div class="mini-stat"><small>AHOLI</small><b>${fmt(total('population'))}</b></div><div class="mini-stat"><small>REYESTR</small><b>${fmt(total('registry'))}</b></div><div class="mini-stat"><small>NOGIRONLIGI BOR</small><b>${fmt(total('disabilities'))}</b></div><div class="mini-stat"><small>YETIM</small><b>${fmt(total('orphans'))}</b></div><div class="mini-stat"><small>KEKSALAR</small><b>${fmt(total('elderly'))}</b></div></div><div class="analysis-block"><h3>HUDUDLAR KESIMIDA</h3><div class="region-table"><div class="region-row header"><span>Hudud</span><span>Aholi</span><span>208 hudud</span><span>Obyekt</span></div>${regs.map(r=>`<div class="region-row clickable" data-region="${esc(r.region)}"><b>${esc(r.region)}</b><span>${fmt(r.pop)}</span><span>${r.districts}</span><span>${r.objects}</span></div>`).join('')}</div></div><div class="analysis-block"><h3>208 JADVAL · USTUVORLIK REYTINGI</h3><div class="rank-list">${rank.map((d,i)=>`<div class="rank-item"><span class="rank-no">${i+1}</span><span class="rank-label"><b>${esc(d.district)}</b><small>${esc(d.region)}</small></span><span class="bar"><i style="width:${Math.max(4,d.totalShare/max*100)}%"></i></span><span class="rank-value">${fmt1(d.totalShare)}</span></div>`).join('')}</div></div>`;
    $$('.region-row[data-region]').forEach(row=>row.onclick=()=>{state.region=row.dataset.region;$('#analysisDrawer').classList.remove('open');applyFilters({fit:true})});
  }
  function openAnalysis(){renderAnalysis();$('#analysisDrawer').classList.add('open');$('#detailDrawer').classList.remove('open')}

  function bind(){
    $('#brandBtn').onclick=fitUzbekistan;$('#fitBtn').onclick=fitUzbekistan;$('#locateBtn').onclick=locate;$('#analysisBtn').onclick=openAnalysis;$('#analysisClose').onclick=()=>$('#analysisDrawer').classList.remove('open');
    $('#objectList').addEventListener('click',e=>{const card=e.target.closest('[data-uid]');if(card)return selectObject(card.dataset.uid,true);if(e.target.closest('[data-more]'))loadMore()});
    $('#objectList').addEventListener('scroll',()=>{const e=$('#objectList');if(e.scrollTop+e.clientHeight>e.scrollHeight-100)loadMore()},{passive:true});
    const onSearch=debounce(e=>{state.q=e.target.value;applyFilters()},120);$('#objectSearch').addEventListener('input',onSearch);
    $('#regionSelect').onchange=e=>{state.region=e.target.value;applyFilters({fit:true})};$('#typeSelect').onchange=e=>{state.type=e.target.value;applyFilters()};$('#selectedOnly').onchange=e=>{state.selectedOnly=e.target.checked;if(state.selectedOnly)state.year='2027';applyFilters({fit:true})};$('#clearFilters').onclick=clearFilters;
    $$('.year-tab').forEach(b=>b.onclick=()=>{state.year=b.dataset.year;state.selectedOnly=false;applyFilters({fit:false})});
    $$('.kpi[data-year]').forEach(b=>b.onclick=()=>{state.year=b.dataset.year;state.selectedOnly=false;applyFilters({fit:false})});
    $('[data-selected]').onclick=()=>{state.year='2027';state.selectedOnly=true;applyFilters({fit:true})};$('[data-analysis]').onclick=openAnalysis;
    $('#mapTypeBtn').onclick=toggleMapTypeMenu;$$('#mapTypeMenu [data-maptype]').forEach(b=>b.onclick=()=>setMapType(b.dataset.maptype));$('#trafficBtn').onclick=toggleTraffic;$('#boundaryBtn').onclick=toggleBoundaries;$('#tiltBtn').onclick=toggleTilt;
    $('#routeClear').onclick=clearRoute;$('#streetClose').onclick=closeStreet;$('#toggleExplorer').onclick=()=>$('#explorer').classList.add('mobile-open');$('#closeExplorer').onclick=()=>$('#explorer').classList.remove('mobile-open');
    document.addEventListener('click',e=>{if(!e.target.closest('#mapTypeMenu')&&!e.target.closest('#mapTypeBtn'))$('#mapTypeMenu').hidden=true});
    window.addEventListener('keydown',e=>{if(e.key==='Escape'){closeDetail();$('#analysisDrawer').classList.remove('open');closeStreet();$('#mapTypeMenu').hidden=true}});
  }

  function boot(){
    setKpis();populateRegions();bind();renderList(true);syncFilters();
    window.__dashboardStats={objects:objects.length,centers2026:D.centers2026.length,proposals2027:D.proposals2027.length,districts208:D.districts208.length,regions:new Set(objects.map(o=>o.region)).size};
    document.body.dataset.dashboardReady='true';
    const start=()=>loadGoogleMaps();if('requestIdleCallback'in window)requestIdleCallback(start,{timeout:900});else setTimeout(start,60);
  }
  document.addEventListener('DOMContentLoaded',boot);
})();
